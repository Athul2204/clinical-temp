from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import LoginView, LoginActivityView


urlpatterns = [

    path('login/', LoginView.as_view(), name="login"),

    path('refresh/', TokenRefreshView.as_view(), name="token_refresh"),

    path('login-history/', LoginActivityView.as_view(), name="login_history"),

]